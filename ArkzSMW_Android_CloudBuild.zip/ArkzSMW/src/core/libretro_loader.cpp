#include <dlfcn.h>
#include <iostream>
#include <string>

using RetroInit = void (*)();
using RetroDeinit = void (*)();
using RetroGetSystemInfo = void (*)(void *);
using RetroLoadGame = bool (*)(const void *);
using RetroRun = void (*)();
using RetroUnloadGame = void (*)();

class LibretroLoader {
private:
    void* library = nullptr;

public:
    bool open(const std::string& path) {
        library = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);

        if (!library) {
            std::cerr << "Erro ao abrir o núcleo: "
                      << dlerror() << '\n';
            return false;
        }

        std::cout << "Biblioteca Snes9x carregada.\n";

        const char* functions[] = {
            "retro_api_version",
            "retro_init",
            "retro_deinit",
            "retro_get_system_info",
            "retro_load_game",
            "retro_run",
            "retro_unload_game"
        };

        for (const char* name : functions) {
            if (!dlsym(library, name)) {
                std::cerr << "Função ausente: "
                          << name << '\n';
                dlclose(library);
                library = nullptr;
                return false;
            }
        }

        std::cout << "Funções principais encontradas.\n";
        return true;
    }

    ~LibretroLoader() {
        if (library) {
            dlclose(library);
        }
    }
};

int main() {
    LibretroLoader loader;

    if (!loader.open(
        "build/cores/snes9x_libretro.so")) {
        return 1;
    }

    std::cout << "Núcleo preparado para integração.\n";
    return 0;
}
