#include <dlfcn.h>
#include <iostream>
#include <cstdint>
#include <cstddef>

#include "../../external-snes9x/libretro/libretro.h"

static bool environment_callback(
    unsigned command, void* data
) {
    switch (command) {
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
            if (data) {
                *static_cast<const char**>(data) = ".";
                return true;
            }
            return false;

        default:
            return false;
    }
}

static void video_callback(
    const void*, unsigned, unsigned, size_t
) {}

static void audio_callback(int16_t, int16_t) {}

static size_t audio_batch_callback(
    const int16_t*, size_t frames
) {
    return frames;
}

static void input_poll_callback() {}

static int16_t input_state_callback(
    unsigned, unsigned, unsigned, unsigned
) {
    return 0;
}

int main() {
    std::cerr << "[1] Abrindo núcleo...\n";

    void* core = dlopen(
        "build/cores/snes9x_libretro.so",
        RTLD_NOW | RTLD_LOCAL
    );

    if (!core) {
        std::cerr << "[ERRO] "
                  << dlerror() << '\n';
        return 1;
    }

    #define LOAD_FUNCTION(name, type) \
        auto name = reinterpret_cast<type>( \
            dlsym(core, #name))

    using SetEnvironment =
        void (*)(retro_environment_t);
    using SetVideo =
        void (*)(retro_video_refresh_t);
    using SetAudio =
        void (*)(retro_audio_sample_t);
    using SetAudioBatch =
        void (*)(retro_audio_sample_batch_t);
    using SetInputPoll =
        void (*)(retro_input_poll_t);
    using SetInputState =
        void (*)(retro_input_state_t);
    using Init = void (*)();
    using Deinit = void (*)();
    using Version = unsigned (*)();

    LOAD_FUNCTION(retro_set_environment, SetEnvironment);
    LOAD_FUNCTION(retro_set_video_refresh, SetVideo);
    LOAD_FUNCTION(retro_set_audio_sample, SetAudio);
    LOAD_FUNCTION(retro_set_audio_sample_batch, SetAudioBatch);
    LOAD_FUNCTION(retro_set_input_poll, SetInputPoll);
    LOAD_FUNCTION(retro_set_input_state, SetInputState);
    LOAD_FUNCTION(retro_init, Init);
    LOAD_FUNCTION(retro_deinit, Deinit);
    LOAD_FUNCTION(retro_api_version, Version);

    if (!retro_set_environment ||
        !retro_set_video_refresh ||
        !retro_set_audio_sample ||
        !retro_set_audio_sample_batch ||
        !retro_set_input_poll ||
        !retro_set_input_state ||
        !retro_init ||
        !retro_deinit ||
        !retro_api_version) {
        std::cerr << "[ERRO] Funcao necessaria ausente.\n";
        dlclose(core);
        return 1;
    }

    std::cerr << "[2] API: "
              << retro_api_version() << '\n';

    std::cerr << "[3] Configurando callbacks...\n";

    retro_set_environment(environment_callback);
    retro_set_video_refresh(video_callback);
    retro_set_audio_sample(audio_callback);
    retro_set_audio_sample_batch(audio_batch_callback);
    retro_set_input_poll(input_poll_callback);
    retro_set_input_state(input_state_callback);

    std::cerr << "[4] Inicializando Snes9x...\n";

    retro_init();

    std::cerr << "[5] Inicializacao concluida!\n";

    retro_deinit();
    dlclose(core);

    std::cerr << "[6] Teste concluido.\n";
    return 0;
}
