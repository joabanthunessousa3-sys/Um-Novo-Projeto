#ifndef ARKZ_SMW_CONTROLLER_HPP
#define ARKZ_SMW_CONTROLLER_HPP

namespace ArkzSMW {

struct Controller {
    bool up = false;
    bool down = false;
    bool left = false;
    bool right = false;

    bool a = false;
    bool b = false;
    bool x = false;
    bool y = false;

    bool start = false;
    bool select = false;
};

}

#endif
