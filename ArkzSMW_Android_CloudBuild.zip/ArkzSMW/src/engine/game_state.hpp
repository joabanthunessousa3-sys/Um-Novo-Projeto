#ifndef ARKZ_SMW_GAME_STATE_HPP
#define ARKZ_SMW_GAME_STATE_HPP

#include <cstdint>

namespace ArkzSMW {

struct GameState {
    bool running = false;
    bool paused = false;

    uint32_t frame = 0;

    int screenWidth = 256;
    int screenHeight = 224;

    void start() {
        running = true;
        paused = false;
        frame = 0;
    }

    void stop() {
        running = false;
    }

    void togglePause() {
        paused = !paused;
    }
};

}

#endif
