#include <iostream>
#include "engine/game_state.hpp"
#include "input/controller.hpp"

int main() {
    ArkzSMW::GameState game;
    ArkzSMW::Controller controls;

    game.start();

    std::cout << "============================\n";
    std::cout << "     ARKZ SMW RECOMPILER\n";
    std::cout << "============================\n";
    std::cout << "Motor iniciado: "
              << (game.running ? "SIM" : "NAO") << '\n';
    std::cout << "Resolucao base: "
              << game.screenWidth << "x"
              << game.screenHeight << '\n';

    controls.right = true;
    controls.a = true;

    std::cout << "Direita pressionada: "
              << (controls.right ? "SIM" : "NAO") << '\n';
    std::cout << "Botao A pressionado: "
              << (controls.a ? "SIM" : "NAO") << '\n';

    game.togglePause();

    std::cout << "Jogo pausado: "
              << (game.paused ? "SIM" : "NAO") << '\n';

    return 0;
}
