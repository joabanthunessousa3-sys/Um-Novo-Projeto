#include <dlfcn.h>
#include <iostream>

int main() {
    const char* path = "build/cores/snes9x_libretro.so";

    void* lib = dlopen(path, RTLD_NOW | RTLD_LOCAL);

    if (!lib) {
        std::cerr << "ERRO: " << dlerror() << '\n';
        return 1;
    }

    std::cout << "Nucleo Snes9x carregado com sucesso!\n";

    dlclose(lib);
    return 0;
}
